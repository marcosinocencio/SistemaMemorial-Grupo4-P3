/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemamemorial;

/**
 *
 * @author alex
 */
public class Memorial {
    private String textoUnico;
    
    public void criar(String textoUnico){}
    public void alterar(String textoUnico){}
}
