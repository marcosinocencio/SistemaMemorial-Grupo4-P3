/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemamemorial;

import java.io.File;

/**
 *
 * @author alex
 */
public class CatalogoDocumento {
    public void adiciona(File doc){}
    public void buscaArquivo(String nomeArquivo){}
    public void removerArquivo(String nomeArquivo){}
    public void getArquivos(){}
}
