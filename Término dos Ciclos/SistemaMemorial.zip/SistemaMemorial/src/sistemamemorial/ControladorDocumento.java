/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemamemorial;

import java.io.File;

/**
 *
 * @author alex
 */
public class ControladorDocumento {
    public boolean enviarDocumento(File documento){
    }
    public boolean confirmarRemocao(boolean confirmacao){
    }
    public void buscaArquivo(String nomeArquivo){
    }
}
