/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemamemorial;

/**
 *
 * @author alex
 */
public class CatalogoUsuario {
    public void verificaUsuario(String login, String email){}
    public void registrarMemorial(String texto){}
    public void remover(Usuario currentUser){}
    public void adiciona(Usuario novo){}
    public void getUsuario(String login, String senha){}
    public void buscarUsuario(String login, String senha){}
    public void getUsuario(String login, String email){}
    public void buscar(String login, String email){}
    public void alterarMemorial(Usuario currentUser, String textoUnico){}
    public void alterarDadosUsuario(String nome, String usuario, String senha, String dataNasc, int sexo, int cpf, int rg, String email, String uf, String enderecoPessoal, String enderecoProfissional, Usuario currentUser){}
}
